import 'dart:math';

import 'package:flutter/material.dart';
import 'package:charts_flutter/flutter.dart' as charts;
import 'package:flutter/cupertino.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_echart/flutter_echart.dart';

Color mainColor = Color(0xFFCADCED);

class chartpage extends StatefulWidget {
  const chartpage({ Key? key }) : super(key: key);

  @override
  _chartpageState createState() => _chartpageState();
}

class _chartpageState extends State<chartpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
  //Here is the content of the page. First, center the chart
  //这里是页面内容，首先将图表居中
      body: Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Container(
              //height
              //高度
              height: 260,
              //Density of filling
              //宽度填充
              width: MediaQuery.of(context).size.width,
              //Set background
              //设置一下背景
              color: mainColor,
              //Here is a method to build left-right sorting
              //封装一个方法构建左右排列的
              child: buildPieChatWidget(),
            ),
          ],
        ),
      ),
    );
  }

  List<EChartPieBean> _dataList = [
    EChartPieBean(title: "rent", number: 2000, color: Colors.lightBlueAccent),
    EChartPieBean(title: "water", number: 600, color: Colors.deepOrangeAccent),
    EChartPieBean(title: "electricity", number: 1200, color: Colors.green),
    EChartPieBean(title: "Network", number: 500, color: Colors.amber),
    EChartPieBean(title: "Property", number: 300, color: Colors.orange),
  ];

  PieChatWidget buildPieChatWidget() {
    return PieChatWidget(
      dataList: _dataList,
      //是否输出日志
      isLog: true,
      //是否需要背景
      isBackground: true,
      //是否画直线
      isLineText: true,
      //背景
      bgColor: Colors.white,
      //是否显示最前面的内容
      isFrontgText: true,
      //默认选择放大的块
      initSelect: 1,
      //初次显示以动画方式展开
      openType: OpenType.ANI,
      //旋转类型
      loopType: LoopType.MOVE,
      //点击回调
      clickCallBack: (int value) {
        print("当前点击显示 $value");
      },
    );
  }
}
